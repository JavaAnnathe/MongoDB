package com.example.mongodbdemo.controller;

import com.example.mongodbdemo.model.Tutorial;
import com.example.mongodbdemo.repository.TutorialRepository;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.http.HttpStatus;

import org.springframework.web.bind.annotation.DeleteMapping;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.http.ResponseEntity;

import java.util.*;


@RestController
@RequestMapping("/api")
public class TutorialController {

  @Autowired
  TutorialRepository tutorialRepository;

	
	  @GetMapping("/tutorials")
	   public ResponseEntity<List<Tutorial>>  getAllTutorials() {
		  List<Tutorial> tutorials = new ArrayList<Tutorial>();
		  
		  tutorials =tutorialRepository.findAll();
		  
		  return new ResponseEntity<>(tutorials, HttpStatus.OK);
	  
	  }
	 

  @GetMapping("/tutorials/{id}")
  public ResponseEntity<Tutorial> getTutorialById(@PathVariable("id") String id) {
	  Optional<Tutorial> tutorialData = tutorialRepository.findById(id);

	  if (tutorialData.isPresent()) {
	    return new ResponseEntity<>(tutorialData.get(), HttpStatus.OK);
	  } else {
	    return new ResponseEntity<>(HttpStatus.NOT_FOUND);
	  }
    
  }

  @PostMapping("/tutorials")
  public ResponseEntity<Tutorial> createTutorial(@RequestBody Tutorial tutorial) {
	  try {
		    //Tutorial _tutorial = tutorialRepository.save(new Tutorial(tutorial.getTitle(), tutorial.getDescription(), false));
		    Tutorial tutorial1 = tutorialRepository.save(tutorial);
		    
		    return new ResponseEntity<>(tutorial1, HttpStatus.CREATED);
		    
		  } catch (Exception e) {
			  
		    return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
		  }
    
  }

	/*
	 * @PutMapping("/tutorials/{id}") public ResponseEntity<Tutorial>
	 * updateTutorial(@PathVariable("id") String id, @RequestBody Tutorial tutorial)
	 * {
	 * 
	 * }
	 * 
	 * @DeleteMapping("/tutorials/{id}") public ResponseEntity<HttpStatus>
	 * deleteTutorial(@PathVariable("id") String id) {
	 * 
	 * }
	 * 
	 * @DeleteMapping("/tutorials") public ResponseEntity<HttpStatus>
	 * deleteAllTutorials() {
	 * 
	 * }
	 * 
	 * @GetMapping("/tutorials/published") public ResponseEntity<List<Tutorial>>
	 * findByPublished() {
	 * 
	 * }
	 */
}