package com.example.mongodbdemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MongodbdemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(MongodbdemoApplication.class, args);
	}

}
